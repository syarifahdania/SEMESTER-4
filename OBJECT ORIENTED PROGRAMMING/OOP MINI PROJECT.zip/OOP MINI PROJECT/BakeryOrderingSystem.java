import java.util.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

enum FoodType {
    BREAD, CAKE, BISCUIT, PASTRY, BEVERAGE
}

enum AllergyTag {
    GLUTEN_FREE, NUT_FREE, DAIRY_FREE, VEGAN
}

enum OrderStatus {
    PENDING, PURCHASED
}

enum PaymentMethod {
    CASH, CARD
}

class FoodItem {
    private final String name;
    private final FoodType type;
    private final double cost;
    private final Set<AllergyTag> allergyTags;
    private final String description;

    public FoodItem(String name, FoodType type, double cost, Set<AllergyTag> allergyTags, String description) {
        this.name = name;
        this.type = type;
        this.cost = cost;
        this.allergyTags = allergyTags;
        this.description = description;
    }

    public String getName() { return name; }
    public FoodType getType() { return type; }
    public double getCost() { return cost; }
    public Set<AllergyTag> getAllergyTags() { return allergyTags; }
    public String getDescription() { return description; }

    @Override
    public String toString() {
        return String.format("RM%.2f | %-20s | %s | Allergies: %s",
                cost, 
                name, 
                description, 
                allergyTags.isEmpty() ? "-" : allergyTags);
    }
}

class OrderItem {
    private final FoodItem foodItem;
    private int quantity;
    private String specialRequest;

    public OrderItem(FoodItem foodItem, int quantity, String specialRequest) {
        this.foodItem = foodItem;
        this.quantity = quantity;
        this.specialRequest = specialRequest;
    }

    public double getTotal() {
        return foodItem.getCost() * quantity;
    }

    public String getSpecialRequest() {
        return specialRequest.isEmpty() ? "-" : specialRequest;
    }

    public FoodItem getFoodItem() { return foodItem; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int quantity) { this.quantity = quantity; }
}

class Order {
    private static int nextId = 1;
    private final int id;
    private final List<OrderItem> items;
    private final LocalDateTime orderTime;
    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");
    private OrderStatus status;
    private PaymentMethod paymentMethod;

    public OrderStatus getStatus() {
        return status;
    }

    public List<OrderItem> getItems() {
        return items;
    }

    public Order() {
        this.id = nextId++;
        this.items = new ArrayList<>();
        this.orderTime = LocalDateTime.now();
        this.status = OrderStatus.PENDING;
    }

    public void addItem(OrderItem item) {
        items.add(item);
    }

    public double getTotal() {
        return items.stream().mapToDouble(OrderItem::getTotal).sum();
    }

    public void completePayment(PaymentMethod method) {
        this.paymentMethod = method;
        this.status = OrderStatus.PURCHASED;
    }

    public boolean isEmpty() {
        return items.isEmpty();
    }

    public String getReceipt() {
        StringBuilder sb = new StringBuilder();
        sb.append("\n=== ORDER RECEIPT ===\n");
        sb.append("Order ID: ").append(id).append("\n");
        sb.append("Order Time: ").append(orderTime.format(formatter)).append("\n\n");
        
        // Table header
        sb.append(String.format("%-5s %-20s %-10s %-8s %-6s %-10s %-30s %-20s %-15s\n", 
            "No.", "Name", "Type", "Price", "Qty", "Total", "Description", "Special Req", "Allergies"));
        sb.append("----------------------------------------------------------------------------------------------------------------------------------\n");
        
        // Table rows
        for (int i = 0; i < items.size(); i++) {
            OrderItem item = items.get(i);
            FoodItem food = item.getFoodItem();
            
            sb.append(String.format("%-5d %-20s %-10s RM%-7.2f %-6d RM%-7.2f %-30s %-20s %-15s\n",
                i + 1,
                food.getName(),
                food.getType().toString().toLowerCase(),
                food.getCost(),
                item.getQuantity(),
                item.getTotal(),
                food.getDescription(),
                item.getSpecialRequest(),
                food.getAllergyTags().isEmpty() ? "-" : food.getAllergyTags()));
        }
        
        // Footer
        sb.append("----------------------------------------------------------------------------------------------------------------------------------\n");
        sb.append(String.format("%121sRM%.2f\n", "Full Total: ", getTotal()));
        if (status == OrderStatus.PURCHASED) {
            sb.append("\nPayment Method: ").append(paymentMethod).append("\n");
        }
        sb.append("Order Status: ").append(status).append("\n");
        return sb.toString();
    }
}

public class BakeryOrderingSystem {
    private final Scanner scanner = new Scanner(System.in);
    private final Map<FoodType, List<FoodItem>> menu;
    private Order currentOrder;

    public BakeryOrderingSystem() {
        this.menu = initializeMenu();
    }

    private Map<FoodType, List<FoodItem>> initializeMenu() {
        Map<FoodType, List<FoodItem>> menu = new EnumMap<>(FoodType.class);
        
        // Breads
        menu.put(FoodType.BREAD, Arrays.asList(
            new FoodItem("Gardenia Bread", FoodType.BREAD, 4.50, 
                EnumSet.of(AllergyTag.DAIRY_FREE), "Soft white bread"),
            new FoodItem("Wholemeal Bread", FoodType.BREAD, 5.20, 
                EnumSet.of(AllergyTag.DAIRY_FREE, AllergyTag.GLUTEN_FREE), "Healthy whole grain bread"),
            new FoodItem("Baguette", FoodType.BREAD, 6.80, 
                EnumSet.of(AllergyTag.VEGAN), "Traditional French bread")
        ));
        
        // Cakes
        menu.put(FoodType.CAKE, Arrays.asList(
            new FoodItem("Chocolate Cake", FoodType.CAKE, 45.00, 
                EnumSet.noneOf(AllergyTag.class), "Rich chocolate flavor"),
            new FoodItem("Red Velvet Cake", FoodType.CAKE, 55.00, 
                EnumSet.of(AllergyTag.NUT_FREE), "Classic red velvet with cream cheese"),
            new FoodItem("Cheesecake", FoodType.CAKE, 38.00, 
                EnumSet.of(AllergyTag.GLUTEN_FREE), "Creamy New York style")
        ));
        
        // Biscuits
        menu.put(FoodType.BISCUIT, Arrays.asList(
            new FoodItem("Butter Cookies", FoodType.BISCUIT, 12.50, 
                EnumSet.noneOf(AllergyTag.class), "Buttery and crumbly"),
            new FoodItem("Almond Biscotti", FoodType.BISCUIT, 15.00, 
                EnumSet.of(AllergyTag.DAIRY_FREE), "Italian almond biscuits"),
            new FoodItem("Shortbread", FoodType.BISCUIT, 10.80, 
                EnumSet.of(AllergyTag.NUT_FREE), "Scottish classic")
        ));
        
        // Pastries
        menu.put(FoodType.PASTRY, Arrays.asList(
            new FoodItem("Croissant", FoodType.PASTRY, 6.80, 
                EnumSet.noneOf(AllergyTag.class), "Flaky French pastry"),
            new FoodItem("Danish Pastry", FoodType.PASTRY, 7.50, 
                EnumSet.of(AllergyTag.NUT_FREE), "Sweet fruit-filled pastry"),
            new FoodItem("Cinnamon Roll", FoodType.PASTRY, 8.20, 
                EnumSet.of(AllergyTag.VEGAN), "Gooey cinnamon goodness")
        ));
        
        // Beverages
        menu.put(FoodType.BEVERAGE, Arrays.asList(
            new FoodItem("Iced Latte", FoodType.BEVERAGE, 8.50, 
                EnumSet.of(AllergyTag.VEGAN), "Cold coffee with milk"),
            new FoodItem("Green Tea", FoodType.BEVERAGE, 5.00, 
                EnumSet.of(AllergyTag.VEGAN, AllergyTag.GLUTEN_FREE), "Refreshing Japanese green tea"),
            new FoodItem("Hot Chocolate", FoodType.BEVERAGE, 7.20, 
                EnumSet.of(AllergyTag.NUT_FREE), "Creamy chocolate drink")
        ));
        
        return menu;
    }

    private void displayMainMenu() {
        while (true) {
            try {
                System.out.println("\n" +
                    "---------Welcome to Our Bakery Ordering System-----------\n" +
                    "This system mainly sells baked goods. Feel free to browse our menu.\n" +
                    "---------------------------------------------------------\n" +
                    "1. Choose Food Type\n" +
                    "2. View Cart\n" +
                    "3. Proceed to Payment\n" +
                    "4. Exit\n" +
                    "---------------------------------------------------------");
                System.out.print("Select an option (1-4): ");

                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                switch (choice) {
                    case 1:
                        browseByFoodType();
                        break;
                    case 2:
                        viewCart();
                        break;
                    case 3:
                        processPayment();
                        break;
                    case 4:
                        if (confirmExit()) {
                            System.out.println("\nThank you for visiting our bakery!");
                            System.exit(0);
                        }
                        break;
                    default:
                        System.out.println("Invalid option! Please enter 1-4");
                        break;
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input! Please enter a number between 1-4.");
                scanner.nextLine(); // Clear invalid input
            }
        }
    }

    private boolean confirmExit() {
        if (currentOrder != null && !currentOrder.isEmpty() && currentOrder.getStatus() != OrderStatus.PURCHASED) {
            System.out.println("\nYou have unpaid items in your cart!");
            System.out.println(currentOrder.getReceipt());
            System.out.print("Are you sure you want to exit? (yes/no): ");
            String confirmation = scanner.nextLine();
            return confirmation.equalsIgnoreCase("yes");
        }
        return true;
    }

    private void browseByFoodType() {
        while (true) {
            try {
                System.out.println("\n=== FOOD TYPES ===");
                int i = 1;
                for (FoodType type : FoodType.values()) {
                    System.out.println(i++ + ". " + type.toString().charAt(0) + 
                        type.toString().substring(1).toLowerCase());
                }
                System.out.println(i + ". Back to Main Menu");
                System.out.print("Select a food type (1-" + i + "): ");

                int typeChoice = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                if (typeChoice == FoodType.values().length + 1) {
                    return; // Back to main menu
                } else if (typeChoice > 0 && typeChoice <= FoodType.values().length) {
                    FoodType selectedType = FoodType.values()[typeChoice - 1];
                    browseFoodItems(selectedType);
                } else {
                    System.out.println("Invalid choice! Please enter 1-" + (FoodType.values().length + 1));
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input! Please enter a number.");
                scanner.nextLine(); // Clear invalid input
            }
        }
    }

    private void browseFoodItems(FoodType type) {
        List<FoodItem> items = menu.get(type);
        
        while (true) {
            try {
                System.out.println("\n=== " + type.toString().toUpperCase() + " MENU ===");
                for (int i = 0; i < items.size(); i++) {
                    System.out.println((i + 1) + ". " + items.get(i));
                }
                System.out.println((items.size() + 1) + ". Back to Food Types");
                System.out.print("Select an item (1-" + (items.size() + 1) + "): ");

                int itemChoice = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                if (itemChoice == items.size() + 1) {
                    return; // Back to food types
                } else if (itemChoice > 0 && itemChoice <= items.size()) {
                    addToCart(items.get(itemChoice - 1));
                } else {
                    System.out.println("Invalid choice! Please enter 1-" + (items.size() + 1));
                }
            } catch (InputMismatchException e) {
                System.out.println("Invalid input! Please enter a number.");
                scanner.nextLine(); // Clear invalid input
            }
        }
    }

    private void addToCart(FoodItem item) {
        try {
            System.out.print("\nEnter quantity (0 to cancel): ");
            int quantity = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            if (quantity < 0) {
                System.out.println("Quantity cannot be negative! Item not added.");
                return;
            } else if (quantity == 0) {
                System.out.println("Item not added to cart.");
                return;
            }

            // Check for duplicate item
            if (currentOrder != null) {
                for (OrderItem orderItem : currentOrder.getItems()) {
                    if (orderItem.getFoodItem().getName().equals(item.getName()) && 
                        orderItem.getSpecialRequest().equals("")) {
                        System.out.print("This item is already in your cart. Update quantity instead? (yes/no): ");
                        String updateChoice = scanner.nextLine();
                        if (updateChoice.equalsIgnoreCase("yes")) {
                            orderItem.setQuantity(orderItem.getQuantity() + quantity);
                            System.out.println("\nQuantity updated! Total now: " + orderItem.getQuantity());
                            return;
                        }
                    }
                }
            }

            String specialRequest = "";
            if (item.getType() == FoodType.CAKE) {
                while (true) {
                    try {
                        System.out.print("Enter cake weight in grams (100-2000): ");
                        int grams = scanner.nextInt();
                        scanner.nextLine(); // Consume newline
                        
                        if (grams < 100 || grams > 2000) {
                            System.out.println("Please enter between 100-2000 grams");
                            continue;
                        }
                        specialRequest = grams + "g";
                        break;
                    } catch (InputMismatchException e) {
                        System.out.println("Invalid input! Please enter a number.");
                        scanner.nextLine(); // Clear invalid input
                    }
                }
            } else if (item.getType() == FoodType.BREAD) {
                System.out.print("Any special request? (e.g., sliced/unsliced): ");
                specialRequest = scanner.nextLine();
            }

            if (currentOrder == null) {
                currentOrder = new Order();
            }
            currentOrder.addItem(new OrderItem(item, quantity, specialRequest));
            System.out.println("\n" + quantity + " x " + item.getName() + " added to cart!");
        } catch (InputMismatchException e) {
            System.out.println("Invalid input! Please enter a valid number.");
            scanner.nextLine(); // Clear invalid input
        }
    }

    private void viewCart() {
        if (currentOrder == null || currentOrder.isEmpty()) {
            System.out.println("\nYour cart is empty!");
            return;
        }

        System.out.println(currentOrder.getReceipt());
        
        try {
            System.out.println("\n1. Remove Item");
            System.out.println("2. Back to Main Menu");
            System.out.print("Select option (1-2): ");
            
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline
            
            if (choice == 1) {
                System.out.print("Enter item number to remove: ");
                int itemNum = scanner.nextInt();
                scanner.nextLine(); // Consume newline
                
                if (itemNum > 0 && itemNum <= currentOrder.getItems().size()) {
                    OrderItem removed = currentOrder.getItems().remove(itemNum - 1);
                    System.out.println("Removed: " + removed.getQuantity() + " x " + 
                        removed.getFoodItem().getName());
                    
                    if (currentOrder.isEmpty()) {
                        currentOrder = null;
                    }
                } else {
                    System.out.println("Invalid item number!");
                }
            }
        } catch (InputMismatchException e) {
            System.out.println("Invalid input! Please enter a number.");
            scanner.nextLine(); // Clear invalid input
        }
    }

    private void processPayment() {
        if (currentOrder == null || currentOrder.isEmpty()) {
            System.out.println("\nYour cart is empty! Please add items first.");
            return;
        }

        try {
            System.out.println(currentOrder.getReceipt());
            System.out.println("=== PAYMENT OPTIONS ===");
            System.out.println("1. Cash");
            System.out.println("2. Card");
            System.out.print("Select payment method (1-2): ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            if (choice == 1) {
                System.out.print("Enter cash amount: RM");
                double cashAmount = scanner.nextDouble();
                scanner.nextLine(); // Consume newline
                
                double total = currentOrder.getTotal();
                if (cashAmount < total) {
                    System.out.println("Insufficient payment! Need RM" + (total - cashAmount) + " more.");
                    return;
                }
                
                currentOrder.completePayment(PaymentMethod.CASH);
                System.out.println("\nPayment with cash successful!");
                System.out.println("Change: RM" + (cashAmount - total));
            } else if (choice == 2) {
                while (true) {
                    System.out.print("Enter card number (XXXX-XXXX-XXXX-XXXX): ");
                    String cardNumber = scanner.nextLine();
                    if (!cardNumber.matches("\\d{4}-\\d{4}-\\d{4}-\\d{4}")) {
                        System.out.println("Invalid format! Please use XXXX-XXXX-XXXX-XXXX format.");
                        continue;
                    }
                    currentOrder.completePayment(PaymentMethod.CARD);
                    System.out.println("\nPayment with card " + cardNumber.substring(0, 4) + "-XXXX-XXXX-XXXX successful!");
                    break;
                }
            } else {
                System.out.println("Invalid payment method selection!");
                return;
            }

            System.out.println("\n=== ORDER COMPLETED ===\n");
            System.out.println("Below are the receipt:");
            System.out.println(currentOrder.getReceipt());

            System.out.print("\nWould you like to continue ordering? (yes/no): ");
            String continueChoice = scanner.nextLine();
            if (!continueChoice.equalsIgnoreCase("yes")) {
                System.out.println("\nThank you for visiting our bakery! Hope you have a nice day!");
                System.exit(0);
            }
            currentOrder = null; // Reset cart after payment
        } catch (InputMismatchException e) {
            System.out.println("Invalid input! Please enter a number.");
            scanner.nextLine(); // Clear invalid input
        }
    }

    public static void main(String[] args) {
        BakeryOrderingSystem system = new BakeryOrderingSystem();
        system.displayMainMenu();
    }
}

