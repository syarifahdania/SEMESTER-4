/*
TEST 2 (PRACTICAL)
SUBJECT CODE    : SECJ2154
SUBJECT NAME    : OBJECT ORIENTED PROGRAMMING
YEAR/COURSE     : 2 (SECB/ SECJ/ SECP/ SECR/ SECV)
TIME            : 02:00 PM– 04:00 PM MYT (2 HOURS)
DATE            : 27th MAY 2025 (TUESDAY)

NAME            : SYARIFAH DANIA BINTI SYED ABU BAKAR
MATRIC NO       : A23CS0183
YEAR/PROGRAM    : 2/SECPH
SECTION         : 02
LECTURER NAME   : DR ZURAINI

Objective:
Refer Question Booklet.
*/

import java.util.ArrayList;

class Bank { //Total 15 marks for Bank class
    private String name;
    private Address address;
    private ArrayList<Account> accounts;

    public Bank(String name, Address address){
        this.name = name;
        this.address = address;
        this.accounts = new ArrayList<>();
    }

    public String getName(){
        return name;
    }

    public String getAddress(){
        return address.getFullAddress();
    }

    public void addAccount(Account account){
        accounts.add(account);
    }

    public void removeAccount(Account account){
        accounts.remove(account);
    }

    public void printAllInfo(){
        System.out.println("Bank Name: " + name);
        System.out.println("Bank Address: " + address);
        System.out.println("Number of Account(s) Registered: " + accounts.size());
        System.out.println("List of Account(s) : ");
        for(int i = 0; i<accounts.size();i++){
            Account acc = accounts.get(i);
            System.out.println((i+1)+ ". Account #: " + acc.getAccountNumber()+ ", Type: " + acc.getType());
        } System.out.println();
    }
}

class Account { //Total 15 marks
    private String accountNumber;
    private String owner;
    private double balance;
    private String type;
    private ArrayList<Transaction> transactions;

    public Account(String accountNumber, String type){
        this.accountNumber = accountNumber;
        this.type = type;
        this.transactions = new ArrayList<>();
    }

    public void setOwner(String owner){
        this.owner = owner;
    }

    public String getAccountNumber(){
        return accountNumber;
    }

    public double getBalance(){
        return balance;
    }

    public String getType(){
        return type;
    }

    public void deposit(double amount){
        balance += amount;
        transactions.add(new Transaction("Deposit ", amount));
    }

    public void withdraw(double amount){
        balance -= amount;
        transactions.add(new Transaction("Withdrawal ", amount));
    }

    public void printAllInfo(){
        System.out.println("Account #: " + accountNumber);
        System.out.println("Owner: " + owner);
        System.out.println("Type: " + type);
        System.out.println("Balance: " + balance);
        System.out.println("Number of Transanction(s): " + transactions.size());
        System.out.println("List of Transaction(s)");
        for(int i = 0; i<transactions.size();i++){
            Transaction t = transactions.get(i);
            System.out.println((i+1)+". Type: " + t.getTransactionType() + ", Amount: " + t.getAmount() );
        }System.out.println();
    }
}

class Customer { //Total 15 marks
    private String customerID;
    private String name;
    private Address address;
    private ArrayList<Account> accounts;

    public Customer(String customerID, String name, Address address){
        this.customerID = customerID;
        this.name = name;
        this.address = address;
        this.accounts = new ArrayList<>();

    }

    public String getCustomerID(){
        return customerID;
    }

    public String getAddress(){
        return address.getFullAddress();
    }

    public void addAccount(Account account, Bank bank){
        accounts.add(account);
        account.setOwner(name);
        bank.addAccount(account);
    }

    public void removeAccount(Account account, Bank bank){
        accounts.remove(account);
        bank.removeAccount(account);
    }

    public void printAllInfo(){
        System.out.println("Customer Name: " + name);
        System.out.println("Customer ID: " + customerID);
        System.out.println("Customer Address: " + address);
        System.out.println("Number of Account(s) Registered: " + accounts.size());
        System.out.println("List of Account(s): ");
        for (int i = 0; i<accounts.size(); i++){
            Account a = accounts.get(i);
            System.out.println((i+1) + ". " + "Account #: " + a.getAccountNumber()+ ", Balance: " + a.getBalance()+ ", Type: " + a.getType());

        }System.out.println();
    }
}

class Address { //Total 5 marks
    private String roadName;
    private String city;
    private String state;
    private String country;

    public Address(String roadName, String city, String state, String country){
        this.roadName = roadName;
        this.city = city;
        this.state = state;
        this.country = country;
    }

    public String getFullAddress(){
        return roadName + ", " + city + ", " + state +", " + country;
    }

    public String toString(){
        return getFullAddress();
    }
}

class Transaction { //Total 5 marks
    private String transactionType;
    private double amount;

    public Transaction(String transactionType, double amount){
        this.transactionType = transactionType;
        this.amount = amount;
    }

    public String getTransactionType(){
        return transactionType;
    }

    public double getAmount(){
        return amount;
    }
}

public class BankingSystem { //Total 15 marks
    public static void main(String[] args) {
        // Create TWO (2) address objects, 1 for bank and 1 for customer
        // 1 marks
        Address bankAddress = new Address("Jalan Kebudayaan", "Skudai", "Johor", "Malaysia");
        // 1 marks
        Address custAddress = new Address("Jalan Pendidikan", "Skudai", "Johor", "Malaysia");        // Create a bank object
        // 1 marks

        // Create a customer object
        Customer cust1 = new Customer("C001","John Doe", custAddress);
        // 1 marks

        // Create an account object and link it to the customer object
        Account acc1 = new Account("A001", "Savings");
        Bank bank1 = new Bank("Beacon Bank", bankAddress);
    
        // 1 marks
        cust1.addAccount(acc1, bank1);
        // 1 marks

        // Create another account object and link it to the customer object
        Account acc2 = new Account("A002", "Current");
        // 1 marks
        cust1.addAccount(acc2, bank1);
        // 1 marks

        // Deposit and withdraw from the first account
        acc1.deposit(1000.0);
        // 1 marks
        acc1.withdraw(200.0);
        // 1 marks

        // Deposit to the second account
        acc2.deposit(2000.0);
        // 1 marks

        // Print info for bank, account 1 & 2, customer
        
        // 0.5 marks
        bank1.printAllInfo();
        // 0.5 marks
        acc1.printAllInfo();
        // 0.5 marks
        acc2.printAllInfo();
        // 0.5 marks
        cust1.printAllInfo();
        // Remove account 2 from customer
        cust1.removeAccount(acc2, bank1);
        // 1 marks

        // Print info for bank, customer
        // 0.5 marks
        
        // 0.5 marks
        bank1.printAllInfo();
        cust1.printAllInfo();
    }
}
