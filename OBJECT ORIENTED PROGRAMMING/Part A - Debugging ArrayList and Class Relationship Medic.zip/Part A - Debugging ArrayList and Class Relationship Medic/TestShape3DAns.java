

import java.util.ArrayList;
import java.util.Scanner;

public class TestShape3DAns {
    public static void main(String[] args) { 
        Boolean exit = false;
        String choice;
        Scanner scan = new Scanner(System.in);

        ArrayList<Shape3D> objList = new ArrayList<>();
        Shape3D s3d = new Shape3D();

        System.out.println("Test Shape3D class");

        while (!exit) {
            System.out.print("\nEnter your choice [cylinder | sphere |  exit ]: ");
            choice = scan.nextLine();

            if (choice.equals("cylinder") ) {
                objList.add(s3d.createCylinder(scan));
            
            } else if (choice.equals("sphere")) {
                objList.add(s3d.createSphere(scan));

            } else if (choice.equals("exit")) {
                exit = true;
            }
        }

        for (int i = 0; i < objList.size(); i++) {
            if (objList.get(i) instanceof Cylinder) {
                Cylinder obj = (Cylinder) objList.get(i);
                System.out.printf("Object #%d Type: Cylinder, Volume: %.3f\n", 
                (i + 1), obj.getVolume());
            } else {
                Sphere obj = (Sphere) objList.get(i);
                System.out.printf("Object #%d Type: Sphere, Volume: %.3f\n", 
                (i + 1), obj.getVolume());
            }
        }

        System.out.printf("TOTAL VOLUME = %.2f\n", Shape3D.TOTAL_VOLUME);

    }
}

class Shape3D {
    public static final double PI = 3.14;
    public static double TOTAL_VOLUME = 0.0;


    public Cylinder createCylinder(Scanner scn) {
 
     System.out.println("Create Cylinder...");

        System.out.print("Radius: ");
        double r = scn.nextDouble();
   
        
        System.out.print("Length: ");
        double l = scn.nextDouble();
   

        
        scn.nextLine();

        
        Cylinder cyl = new Cylinder(r,l);
        TOTAL_VOLUME += cyl.getVolume();

        
        return cyl;
    }

    public Sphere createSphere(Scanner scn) {

        System.out.println("Create Sphere...");

        System.out.print("Radius: ");
        double r = scn.nextDouble();
        
        
        scn.nextLine();

        
        Sphere sph = new Sphere(r);
        TOTAL_VOLUME += sph.getVolume();

        
        return sph;
    }

}

class Cylinder extends Shape3D {
    private double radius, height;
    

    
    public Cylinder() { }
    public Cylinder(double r, double h) { 
        this.radius = r;
        this.height = h;
 

    }

    public double getVolume() {
        return Shape3D.PI * Math.pow(radius, 2) * height;
    }
}

class Sphere extends Shape3D{
    private double radius;
    
    
    public Sphere(double r) {
        this.radius = r;
    }

    public double getVolume() { 
        return 4.0 / 3.0 * Shape3D.PI * Math.pow(radius, 3);
    }
}

